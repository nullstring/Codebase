#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <stack>
#include <queue>
#include <utility>
#include <bitset>
#include <algorithm>

//General Macros
#define S(a) scanf("%d", &a)
#define S_LL(a) scanf("%lld", &a)
#define S_DOUBLE(a) scanf("%lf", &a)
#define S_STRING(a) scanf("%s", &s)
#define FOR(i,m,n) for((i) = (m);  (i) <= (n); (i)++)

using namespace std;

int main(){
	int T;
	S(T);
	while(T--){
		int B; long long C;
		S(B);
		S_LL(C);

		//bitset<50> C_bits(C);

		//cout << B << " "  << C << " " << C_bits << endl;
		int last = (int)(pow(2, B) - 1);
		int B_count[1024] =  {};

		int  window = last;

		int i, shift_till = ceil(log(C)/log(2));
		//cout << shift_till << endl << endl;

		FOR(i,0,shift_till-B)
		{
			int temp = (C >> i) & window;
			//cout << (C_bits >> i)  << "&" << window << "=" << temp  << endl;
			
			int b;
			FOR(b,0,last){
				if (temp == b)
					B_count[b]++;
			}

			//window <<= 1;
		}

		
		FOR(i,0,last)
		{
			printf("%d", B_count[i]);
		}
		printf("\n");
		
	}

	return 0;
}
