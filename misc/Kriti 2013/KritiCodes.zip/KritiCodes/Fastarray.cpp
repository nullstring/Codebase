#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <stack>
#include <queue>
#include <utility>
#include <bitset>
#include <algorithm>

#define MAX 1000000
//General Macros
#define S(a) scanf("%d", &a)
#define S_DOUBLE(a) scanf("%lf", &a)
#define S_STRING(a) scanf("%s", &s)
#define FOR(i,m,n) for((i) = (m);  (i) <= (n); (i)++)

using namespace std;

int main(){
	int T;
	S(T);

	while(T--){
		int L, E, Q;
		S(L);
		S(E);

		int ele[L], i;
		FOR(i,0,L-1)
		{
			ele[i] = E;
		}
		
		S(Q);
		while(Q--){
			int q, index, val; 
			S(q);
			S(index);
			if (q==1){
				S(val);
				ele[index]= val;
			}
			else if (q==0){
				printf("%d\n", ele[index]);
			}
		}
	}

	return 0;
}
