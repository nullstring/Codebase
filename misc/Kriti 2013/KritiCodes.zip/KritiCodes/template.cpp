#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <stack>
#include <queue>
#include <utility>
#include <bitset>
#include <algorithm>

//General Macros
#define S(a) scanf("%d", &a)
#define S_DOUBLE(a) scanf("%lf", &a)
#define S_STRING(a) scanf("%s", &s)
#define FOR(i,m,n) for((i) = (m);  (i) <= (n); (i)++)


typedef vector<int> vi;
typedef vector<int> vi;

using namespace std;

int main(){

	


}
