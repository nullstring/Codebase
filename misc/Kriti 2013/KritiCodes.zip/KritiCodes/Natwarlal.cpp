#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <stack>
#include <queue>
#include <utility>
#include <bitset>
#include <algorithm>

//General Macros
#define S(a) scanf("%d", &a)
#define S_DOUBLE(a) scanf("%lf", &a)
#define S_STRING(a) scanf("%s", a)
#define S_CHAR(a) scanf("%c", &a)
#define FOR(i,m,n) for((i) = (m);  (i) <= (n); (i)++)

using namespace std;

int main(){
	int T;
	scanf("%d",&T);

	while(T--){
		int N;
		S(N);

		int count[502][502];
		int count1[502][502];
		int i, j;

		char mat[N+1][N+1];
		FOR(i, 1, N){
			FOR(j,1,N)
			{
				cin >> mat[i][j];
			}
		}
		char str[500];
		scanf("%s", str);
		int len = strlen(str);


		/*FOR(i, 1, N){
		  FOR(j,1,N){
		  cout <<  mat[i][j] << " ";
		  }
		  cout << endl;
		  }
		  cout << str << endl ; */


		FOR(i, 1, N){
			FOR(j,1,N){
				count1[i][j] = 0;
				count[i][j] = 0;
				if (mat[i][j] == str[len-1]){
					count1[i][j] = 1;
				}	
			}
		}
			/*FOR(i, 1, N){
				FOR(j,1,N){
					cout << count1[i][j] << " ";
				}
			cout << endl;
			}*/
		
		int k;
		for(k =len-2;k >= 0 ; k--){
			FOR(i, 1, N){
				FOR(j,1,N){
					count[i][j] = 0;
					if (mat[i][j] == str[k]){
						count[i][j] = count1[i-1][j-1] + count1[i-1][j+1] +count1[i+1][j-1] +count1[i+1][j+1];
					}	
				}
			}
			FOR(i, 1, N){
				FOR(j,1,N){
					count1[i][j] = count[i][j];
					//cout << count1[i][j] << " ";
				}
				//cout << endl;
			}
		}

		int sum = 0;
		FOR(i, 1, N)
			FOR(j,1,N)
			{
				sum += count[i][j];
			}

		printf("%d\n", sum);

	}
}
